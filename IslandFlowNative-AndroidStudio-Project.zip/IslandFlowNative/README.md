# IslandFlow Native — Android Studio project

This is a native Android starter project for a floating Dynamic Island-style overlay, targeted at Android 11-era phones such as the Realme C21.

## Implemented Android integrations
- `SYSTEM_ALERT_WINDOW` permission and `TYPE_APPLICATION_OVERLAY` floating window.
- Foreground service with an ongoing notification so Android can keep the overlay service running.
- `NotificationListenerService` for notification title/text previews after the user explicitly enables Notification access.
- Media session metadata observation (requires Notification access).
- Battery-charging broadcast updates.
- Draggable pill with animated expand/collapse.
- Optional boot receiver to restart the overlay after reboot, subject to Android/OEM background restrictions.

## Build the APK
1. Install Android Studio on a computer.
2. Open this `IslandFlowNative` folder in Android Studio.
3. Let Gradle sync; install Android SDK Platform 35 and a compatible JDK (17).
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to the Realme C21 and install it. If Android asks, allow installation from that file manager/browser.

## First-time setup on the phone
1. Open IslandFlow.
2. Tap **Allow display over other apps** and enable the permission for IslandFlow.
3. Tap **Enable notification access** and explicitly enable IslandFlow in Android's Notification access screen.
4. Return to IslandFlow and tap **Start Dynamic Island**.
5. Return to the home screen. The floating pill should be visible.

## Important limitations / privacy
- Android does not allow an app to silently grant itself overlay or notification access. You must enable both in system settings.
- Notification access can expose notification content from other apps. This starter only displays the title and short text in the overlay; it does not upload or save notification contents.
- Media-session metadata is observed, but media transport buttons and call-answer/decline integration are not yet implemented. Incoming call UI depends on what the phone's dialer posts as a notification.
- Android 11 and Realme UI may restrict background startup. If it stops, open IslandFlow again and start it. Auto-start/background permission names vary by Realme UI version.
- This is an Android Studio source project, not a precompiled APK. Build it with Android Studio to produce the installable APK.
