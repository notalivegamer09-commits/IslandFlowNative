package com.islandflow.realme

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Handler
import android.os.Looper

class IslandNotificationListener : NotificationListenerService() {
    companion object {
        @Volatile var pushToOverlay: ((String, String) -> Unit)? = null

        fun isEnabled(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver, "enabled_notification_listeners"
            ) ?: return false
            return enabled.contains(context.packageName)
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var sessions: MediaSessionManager? = null

    override fun onListenerConnected() {
        super.onListenerConnected()
        sessions = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        refreshMedia()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString()
        val text = extras.getCharSequence("android.text")?.toString()
        if (!title.isNullOrBlank()) {
            val safeTitle = title.take(42)
            val safeText = (text ?: "New notification").take(72)
            mainHandler.post { pushToOverlay?.invoke(safeTitle, safeText) }
        }
        refreshMedia()
    }

    private fun refreshMedia() {
        try {
            val active = sessions?.getActiveSessions(
                ComponentName(this, IslandNotificationListener::class.java)
            ) ?: return
            val controller = active.firstOrNull() ?: return
            val metadata = controller.metadata
            val song = metadata?.getString("android.media.metadata.TITLE") ?: "Media playing"
            val artist = metadata?.getString("android.media.metadata.ARTIST") ?: "Now playing"
            val state = controller.playbackState?.state
            val status = if (state == 3) "Playing" else "Paused"
            mainHandler.post {
                pushToOverlay?.invoke(song.take(42), "$artist • $status")
            }
        } catch (_: SecurityException) {
            // Notification access has not been granted yet.
        }
    }
}
