package com.islandflow.realme

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import android.animation.ValueAnimator
import android.view.Window
import android.view.WindowManager.LayoutParams

class IslandOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var island: LinearLayout? = null
    private var expanded = false
    private var titleView: TextView? = null
    private var detailView: TextView? = null
    private var batteryReceiver: BroadcastReceiver? = null
    private var currentTitle = "IslandFlow ready"
    private var currentDetail = "Tap to expand • Drag to move"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(71, buildNotification())
        if (Settings.canDrawOverlays(this)) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            createIsland()
            registerBattery()
            IslandNotificationListener.pushToOverlay = { title, detail ->
                currentTitle = title
                currentDetail = detail
                updateContent()
                expand()
            }
        } else {
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_STICKY

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("island_running", "IslandFlow service",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "island_running") else Notification.Builder(this)
        return builder.setContentTitle("IslandFlow is active")
            .setContentText("Tap IslandFlow to manage your floating island")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true).build()
    }

    @Suppress("DEPRECATION")
    private fun createIsland() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(15, 9, 15, 9)
            background = rounded(Color.BLACK, 28f)
            elevation = 18f
        }
        val dot = TextView(this).apply {
            text = "●"
            textSize = 10f
            setTextColor(Color.rgb(67, 230, 151))
        }
        val mini = TextView(this).apply {
            text = "IslandFlow"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(7, 0, 3, 0)
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        titleView = TextView(this).apply {
            text = currentTitle
            textSize = 13f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        detailView = TextView(this).apply {
            text = currentDetail
            textSize = 11f
            setTextColor(Color.LTGRAY)
            setPadding(0, 4, 0, 0)
        }
        content.addView(titleView)
        content.addView(detailView)
        root.addView(dot)
        root.addView(mini)
        root.addView(content)
        val params = LayoutParams(
            dp(138), dp(42),
            if (Build.VERSION.SDK_INT >= 26) LayoutParams.TYPE_APPLICATION_OVERLAY
            else LayoutParams.TYPE_PHONE,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(9)
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(root, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (kotlin.math.abs(event.rawX - touchX) < 8 &&
                        kotlin.math.abs(event.rawY - touchY) < 8) toggleExpanded()
                    true
                }
                else -> true
            }
        }
        island = root
        try { windowManager.addView(root, params) } catch (_: Exception) { stopSelf() }
    }

    private fun toggleExpanded() {
        expanded = !expanded
        val view = island ?: return
        val content = view.getChildAt(2)
        content.visibility = if (expanded) View.VISIBLE else View.GONE
        val targetW = if (expanded) dp(285) else dp(138)
        val targetH = if (expanded) dp(82) else dp(42)
        val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 380
            interpolator = OvershootInterpolator(0.8f)
            addUpdateListener { value ->
                val fraction = value.animatedValue as Float
                val p = view.layoutParams as LayoutParams
                val fromW = if (expanded) dp(138) else dp(285)
                val fromH = if (expanded) dp(42) else dp(82)
                p.width = (fromW + (targetW - fromW) * fraction).toInt()
                p.height = (fromH + (targetH - fromH) * fraction).toInt()
                windowManager.updateViewLayout(view, p)
            }
        }
        animator.start()
        if (expanded) updateContent()
    }

    private fun expand() {
        if (!expanded) toggleExpanded() else updateContent()
    }

    private fun updateContent() {
        titleView?.text = currentTitle
        detailView?.text = currentDetail
    }

    private fun registerBattery() {
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
                val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
                if (plugged != 0) {
                    currentTitle = "⚡ Charging • $pct%"
                    currentDetail = "Your phone is charging"
                    updateContent()
                }
            }
        }
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        setStroke(dp(1), Color.rgb(65, 65, 75))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        IslandNotificationListener.pushToOverlay = null
        try { batteryReceiver?.let { unregisterReceiver(it) } } catch (_: Exception) { }
        try { island?.let { windowManager.removeView(it) } } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
